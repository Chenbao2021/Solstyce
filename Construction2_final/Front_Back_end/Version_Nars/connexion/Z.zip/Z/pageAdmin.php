<?php
    session_start();
    require 'signin.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head> 
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Solstyce</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="stylePage.css">
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">  
    </head>
    <body>
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo2.png" alt="Logo">
            </div>
            <nav class="main-menu">
                <ul>
                    <li>
                        <a href="#">
                            <?php
                                configurationConnection();
                            ?>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa fa-home fa-2x"></i>
                            <span class="nav-text">Tableau de bord</span>
                        </a>
                    </li>
                    <!-- Que pour l admin -->
                    <li class="has-subnav">
                        <a href="#">
                            <i class="fa fa-user fa-2x"></i>
                            <span class="nav-text">Profile</span>
                        </a>  
                    </li>

                    <!--  -->  
                   
                    <li class="has-subnav">
                        <a href="#">
                        <i class="fa fa-pie-chart fa-2x"></i>
                            <span class="nav-text">
                                Statistiques
                            </span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <i class="fa fa-line-chart fa-2x"></i>
                            <span class="nav-text">Graphes </span>
                        </a>
                    </li>
                
                    <li>
                        <a href="#">
                            <i class="fa fa-table fa-2x"></i>
                            <span class="nav-text">Tableaux</span>
                        </a>
                    </li>

                    <li class="has-subnav">
                        <a href="#">
                        <i class="fa fa-folder-open-o fa-2x"></i>
                            <span class="nav-text">Historique</span>
                        </a>   
                    </li>

                    <!-- Que pour l admin -->
                    <li>
                        <a href="#">
                        <i class="fa fa-gear fa-2x"></i>
                            <span class="nav-text">Paramêtres </span>
                        </a>
                    </li>
                    <!--  -->
                    
                    <li>
                        <a href="#">
                        <i class="fa fa-question-circle fa-2x"></i>
                            <span class="nav-text">
                                Infos 
                            </span>
                        </a>
                    </li>
                </ul>
                    <ul class="logout">
                        <li>
                            <a href="index.html">
                                <i class="fa fa-power-off fa-2x"></i>
                                <span class="nav-text">Déconnexion</span>
                            </a>
                        </li>  
                    </ul>
            </nav>

        </div>
    </body>
</html>






