<?php
        if(isset($_GET['text'])){
            modification();
        }elseif(isset($_GET['logo'])){
            modificationLogo();
        }
        header("Location:index.php");
?>


<?php
//Changer de text
function modification(){
    $nouveau=$_GET["q"];
    $filepath="index.php";

    $fp1=fopen("textAffichage.txt",'r');
    $ancien=fread($fp1,filesize("textAffichage.txt"));
    fclose($fp1);

    $fp1=fopen("textAffichage.txt",'w');
    fwrite($fp1,$nouveau);
    fclose($fp1);

    $fp = fopen($filepath,'r');
    $fichier=fread($fp,filesize($filepath));
    $str = str_replace($ancien,$nouveau, $fichier);
        fclose($fp);

    $fp=fopen($filepath,'w');
    fwrite($fp,$str);
    fclose($fp);
 
}

function modificationLogo(){
    $nouveau=$_GET["q"];
    $filepath="pageAdmin.php";
    
    $fp1=fopen("logo.txt",'r');
    $ancien=fread($fp1,filesize("logo.txt"));
    fclose($fp1);
    
    $fp1=fopen("logo.txt",'w');
    fwrite($fp1,$nouveau);
    fclose($fp1);
    
    
    
    $fp = fopen($filepath,'r');
    $fichier=fread($fp,filesize($filepath));
    $str = str_replace($ancien,$nouveau, $fichier);
    fclose($fp);
    
    $fp=fopen($filepath,'w');
     fwrite($fp,$str);
    fclose($fp);

}

?>