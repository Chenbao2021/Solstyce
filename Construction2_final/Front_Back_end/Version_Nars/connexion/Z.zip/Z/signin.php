<?php


function configurationConnection(){
    echo '<div id="configuration" style="text-align: center;">';
    if(isset($_SESSION['userName'])){
        echo   '
                Bonjour,mr '.$_SESSION["userName"].'<br>
                <form  methode="GET" >
                <input type="submit" name="deconnecter" value="Deconencter"/>
                <br>
                <input type="submit" name="text" value="text"/>
                <input type="submit" name="logo" value="logo"/>

                </form>
                '
                ;
        if(isset($_GET['text'])){
            echo '
                <form action="index1.php" methode="GET" >
                    <input type="text" id="text" name="q" style="width:200px; height:30px;">
                <input type="submit" name="text" value="upload"/>            
            ';
        }elseif(isset($_GET['logo'])){
            echo '
                <form action="index1.php" methode="GET" >
                    <input type="text" id="text" name="q" style="width:200px; height:30px;">
                <input type="submit" name="logo" value="upload"/>            
            ';
        }
    }else{
        echo '
            <form  method="POST">
            Username:<input type="text" name="userName" placehold="account name"><br>
            Password:<input type="text" name="password" placehold="mot de passe"><br>
            <input type="submit" name="connection" value="connection">
            <input type="submit" name="inscription" value="inscription">
            </form>
            ';
        }
    echo '<br></div>';

    if(isset($_GET['deconnecter'])){
        unset($_SESSION['userName']);
        unset($_SESSION['password']);
        header("Location:/index.php");
    }
}


function verifieConnection(){
    if(isset($_SESSION['userName'])){
        header("Location:pageAdmin.php");
    }
if(isset($_POST['inscription'])){
    if(isset($_POST["userName"]) && isset($_POST["password"])){
        if(!countExistance($_POST["userName"])){
            createUser($_POST["userName"],$_POST["password"]);
        }else{
            echo "<script> alert(\"Cette compte existe déjà!\") </script>";
        }
    }
}elseif(isset($_POST['connection'])){
    if(getAccountByName($_POST['userName']) <> false && getAccountByName($_POST['userName']) === $_POST['password'] ){
        $_SESSION['userName']=$_POST['userName'];
        $_SESSION['password']=$_POST['password'];
        header("Location:pageAdmin.php");
    }else{
        echo "<script> alert(\"Votre mot de passe est incorrect\") </script>";
    }
}
}

function createFile()
{
    $path=__DIR__ . "/users.json" ;
    if(!file_exists($path)){
            file_put_contents($path, json_encode([]));
            #car json est enregistre dans un [*]
        }

}

function createUser($userName,$password)
{
    $path=__DIR__ . "/users.json" ;
    if(isset($_POST["userName"]) && isset($_POST["password"])){
        createFile();
        $file=json_decode(file_get_contents($path));
        $file[]=[
            'userName'=>$userName,
            'password'=>$password,
        ];
        file_put_contents($path,json_encode($file));
    }
    else echo "info incomplet";
}

function countExistance(string $userName):bool
{
    $path=__DIR__ . "/users.json" ;
    createFile();
    $file=json_decode(file_get_contents($path),true);
    foreach($file as $user){
        if($user['userName'] == $userName){
            return true;
        }
    }
    return false;
}

function getAccountByName(string $userName){
    if(countExistance($userName)){
        $path=__DIR__ . "/users.json" ;
        $file=json_decode(file_get_contents($path),true);
    
        foreach($file as $user){
            if($user['userName'] == $userName){
                return $user['password'];
            }
        }
    }
    return false;
}
?>